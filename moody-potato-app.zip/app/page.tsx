"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"

const MoodyPotatoApp = () => {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [question, setQuestion] = useState("")
  const [isThinking, setIsThinking] = useState(false)
  const [thoughtIndex, setThoughtIndex] = useState(0)
  const [showResult, setShowResult] = useState(false)
  const [potatoPosition, setPotatoPosition] = useState({ x: 50, y: 50 })
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [chaseTimer, setChaseTimer] = useState(30)
  const [isChaseActive, setIsChaseActive] = useState(false)
  const [hasWon, setHasWon] = useState(false)
  const [potatoCaught, setPotatoCaught] = useState(false)
  const [activeSection, setActiveSection] = useState("main")
  const containerRef = useRef<HTMLDivElement>(null)
  const [showRoast, setShowRoast] = useState(false)
  const [currentRoast, setCurrentRoast] = useState("")

  // New features
  const [currentTheme, setCurrentTheme] = useState("chaotic-pink")
  const [currentPersona, setCurrentPersona] = useState("default")
  const [potatoMood, setPotatoMood] = useState(50) // 0-100 scale
  const [lastInteraction, setLastInteraction] = useState(Date.now())
  const [showIdleAnimation, setShowIdleAnimation] = useState(false)
  const [fortuneCookie, setFortuneCookie] = useState("")
  const [showFortune, setShowFortune] = useState(false)
  const [isPanicMode, setIsPanicMode] = useState(false)
  const [interactionCount, setInteractionCount] = useState(0)

  const themes = {
    "chaotic-pink": {
      name: "Chaotic Pink",
      bg: "from-pink-400 via-purple-500 to-blue-500",
      accent: "pink-500",
      text: "white",
    },
    "dark-academia": {
      name: "Dark Academia",
      bg: "from-gray-800 via-amber-900 to-black",
      accent: "amber-600",
      text: "amber-100",
    },
    cottagecore: {
      name: "Cottagecore Sadness",
      bg: "from-green-300 via-yellow-200 to-pink-200",
      accent: "green-600",
      text: "green-800",
    },
    vaporwave: {
      name: "Retro Vaporwave",
      bg: "from-purple-600 via-pink-500 to-cyan-400",
      accent: "cyan-400",
      text: "white",
    },
  }

  const personas = {
    default: { name: "Classic Potato", emoji: "🥔", color: "bg-yellow-200" },
    therapist: { name: "Dr. Potato", emoji: "🧠", color: "bg-blue-200" },
    gossip: { name: "Tea Potato", emoji: "☕", color: "bg-pink-200" },
    shy: { name: "Shy Potato", emoji: "🙈", color: "bg-purple-200" },
    passive: { name: "Salty Potato", emoji: "😒", color: "bg-gray-200" },
  }

  const fortuneCookies = [
    "Everything happens for a reason. Sometimes the reason is you made a dumb decision.",
    "You are exactly where you need to be. Unfortunately, that's still your bedroom at 3 PM.",
    "The universe has a plan for you. The plan is chaos.",
    "You're not behind in life. Life is just moving too fast.",
    "Your vibe attracts your tribe. Your vibe is anxiety.",
    "Trust the process. The process is a mess, but trust it anyway.",
    "You're doing better than you think. Which isn't saying much, but still.",
    "Everything will work out in the end. Define 'work out.'",
    "You are enough. Enough what? Nobody knows.",
    "Follow your dreams. Your dreams are weird, but okay.",
  ]

  const overthinkingThoughts = {
    default: [
      "What if potatoes have feelings?",
      "Am I making the right choice?",
      "Is this even important?",
      "What if I regret this later?",
      "What if this is all a simulation?",
      "Am I potato enough for this decision?",
      "What would a wise potato say?",
      "What if I'm missing the point entirely?",
      "Should I make a pros and cons list?",
      "What if starting over is the problem?",
      "Is this question even relevant?",
      "What would future me think?",
      "Should I start over?",
      "What if everything is connected?",
      "Am I overthinking overthinking?",
    ],
    therapist: [
      "Am I projecting my own issues onto this question?",
      "What would Freud say about this?",
      "Is this a defense mechanism?",
      "Are we avoiding the real issue here?",
      "What's the underlying trauma?",
      "Is this about your relationship with your mother?",
      "Are you ready to unpack this?",
      "What would your inner child say?",
      "Is this triggering something deeper?",
      "Are we dealing with abandonment issues?",
      "What's your attachment style?",
      "Is this self-sabotage?",
      "Are you gaslighting yourself?",
      "What boundaries need to be set?",
      "Is this codependency?",
    ],
    gossip: [
      "But what did they REALLY mean by that?",
      "I bet there's more to this story...",
      "Who else knows about this?",
      "Are they talking about you behind your back?",
      "What if everyone already knows?",
      "Is this going to be awkward at the group chat?",
      "What would your ex think about this?",
      "Are you being subtweeted right now?",
      "What if this gets back to them?",
      "Is someone screenshotting this conversation?",
      "What's the real tea here?",
      "Are you about to become the main character?",
      "What if this ends up on their story?",
      "Is this going to start drama?",
      "Who's going to pick sides?",
    ],
    shy: [
      "What if I'm bothering everyone?",
      "Maybe I shouldn't have asked...",
      "Am I being too needy?",
      "What if they think I'm stupid?",
      "I probably said something wrong...",
      "Maybe I should just disappear...",
      "What if I'm too much?",
      "Am I making this weird?",
      "Should I apologize for existing?",
      "What if they're just being polite?",
      "Maybe I misunderstood everything...",
      "Am I overthinking their tone?",
      "What if I'm the problem?",
      "Should I just say never mind?",
      "Maybe I don't deserve help...",
    ],
    passive: [
      "Why do I even bother asking?",
      "Of course this would happen to me.",
      "Everyone else has it figured out.",
      "This is probably my fault somehow.",
      "Why does everything have to be so complicated?",
      "I bet other potatoes don't deal with this.",
      "Great, another thing to worry about.",
      "This is fine. Everything is fine.",
      "Why did I think this would work?",
      "I should have known better.",
      "Typical. Just typical.",
      "What's the point anyway?",
      "I'm probably overreacting. Again.",
      "Why can't things just be simple?",
      "I guess I'll just deal with it. Like always.",
    ],
  }

  // Add atmosphere configurations for each persona
  const personaAtmospheres = {
    default: {
      thinkingBg: "from-purple-600 via-pink-500 to-indigo-600",
      bubbleStyle: "animate-pulse",
      spinSpeed: "animate-spin",
      textColor: "text-white",
    },
    therapist: {
      thinkingBg: "from-blue-800 via-indigo-700 to-purple-800",
      bubbleStyle: "animate-pulse shadow-2xl",
      spinSpeed: "animate-spin-slow",
      textColor: "text-blue-100",
    },
    gossip: {
      thinkingBg: "from-pink-500 via-rose-400 to-orange-400",
      bubbleStyle: "animate-bounce",
      spinSpeed: "animate-spin-fast",
      textColor: "text-white",
    },
    shy: {
      thinkingBg: "from-gray-400 via-blue-300 to-purple-300",
      bubbleStyle: "animate-pulse opacity-80",
      spinSpeed: "animate-spin-slow",
      textColor: "text-gray-700",
    },
    passive: {
      thinkingBg: "from-gray-600 via-slate-500 to-gray-700",
      bubbleStyle: "animate-none",
      spinSpeed: "animate-spin-reverse",
      textColor: "text-gray-200",
    },
  }

  // Idle animation timer
  useEffect(() => {
    const checkIdle = setInterval(() => {
      if (Date.now() - lastInteraction > 10000 && activeSection === "main") {
        setShowIdleAnimation(true)
        setTimeout(() => setShowIdleAnimation(false), 5000)
      }
    }, 5000)
    return () => clearInterval(checkIdle)
  }, [lastInteraction, activeSection])

  // Update interaction timestamp
  const updateInteraction = () => {
    setLastInteraction(Date.now())
    setInteractionCount((prev) => prev + 1)
  }

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000)
    return () => clearInterval(timer)
  }, [])

  const getPotatoMood = () => {
    const hour = currentTime.getHours()
    if (hour >= 6 && hour < 12)
      return {
        mood: "morning",
        message: getPersonaMessage("morning"),
        expression: personas[currentPersona].emoji,
        color: personas[currentPersona].color,
      }
    else if (hour >= 12 && hour < 18)
      return {
        mood: "afternoon",
        message: getPersonaMessage("afternoon"),
        expression: personas[currentPersona].emoji,
        color: personas[currentPersona].color,
      }
    else
      return {
        mood: "night",
        message: getPersonaMessage("night"),
        expression: personas[currentPersona].emoji,
        color: personas[currentPersona].color,
      }
  }

  const getPersonaMessage = (timeOfDay: string) => {
    const messages = {
      default: {
        morning: "Let's overthink today's decisions!",
        afternoon: "Too late to fix things, let's think more!",
        night: "Can't sleep? Perfect time to overthink.",
      },
      therapist: {
        morning: "How are we feeling about today's challenges?",
        afternoon: "Let's unpack what's really bothering you.",
        night: "What's keeping your mind active tonight?",
      },
      gossip: {
        morning: "Spill the tea! What's the drama today?",
        afternoon: "I heard some interesting things... want to discuss?",
        night: "Late night thoughts hit different, don't they?",
      },
      shy: {
        morning: "Um... hi... how are you feeling?",
        afternoon: "I hope your day is going okay...",
        night: "It's okay to feel overwhelmed sometimes...",
      },
      passive: {
        morning: "Oh, you're back. Cool, I guess.",
        afternoon: "Still here? Must be nice having time for this.",
        night: "Can't sleep either? Join the club.",
      },
    }
    return messages[currentPersona]?.[timeOfDay] || messages.default[timeOfDay]
  }

  const currentMood = getPotatoMood()

  const getPersonaAnswer = () => {
    const answers = {
      default: [
        "Maybe. 🤷‍♂️",
        "The answer is potato. It's always potato.",
        "I've thought about it... still no idea.",
        "After all that thinking... I forgot the question.",
      ],
      therapist: [
        "What do YOU think the answer is?",
        "How does this question make you feel?",
        "Let's explore why this matters to you.",
        "The answer lies within you. I'm just a potato.",
      ],
      gossip: [
        "Honestly? That's so last season.",
        "I heard someone else asking the same thing...",
        "Between you and me? Definitely yes.",
        "The streets are saying... maybe not.",
      ],
      shy: [
        "I... I think maybe yes? Sorry if that's wrong...",
        "Um, I don't really know... sorry...",
        "Maybe ask someone smarter than me?",
        "I hope I'm not disappointing you...",
      ],
      passive: [
        "Do whatever. I'm just a potato.",
        "Sure, make another questionable life choice.",
        "Why are you asking me? I literally can't move.",
        "Fine. Yes. Happy now?",
      ],
    }
    const personaAnswers = answers[currentPersona] || answers.default
    return personaAnswers[Math.floor(Math.random() * personaAnswers.length)]
  }

  const startOverthinking = () => {
    if (!question.trim()) return
    updateInteraction()
    setPotatoMood(Math.max(0, potatoMood - 10))
    setIsThinking(true)
    setThoughtIndex(0)
    setShowResult(false)
    setActiveSection("thinking")

    const personaThoughts = overthinkingThoughts[currentPersona] || overthinkingThoughts.default

    const interval = setInterval(
      () => {
        setThoughtIndex((prev) => {
          if (prev >= personaThoughts.length - 1) {
            clearInterval(interval)
            setTimeout(() => {
              setIsThinking(false)
              setShowResult(true)
            }, 800)
            return prev
          }
          return prev + 1
        })
      },
      currentPersona === "gossip" ? 100 : currentPersona === "shy" ? 200 : 150,
    ) // Different speeds per persona
  }

  const crackFortuneCookie = () => {
    updateInteraction()
    setPotatoMood(Math.min(100, potatoMood + 5))
    const randomFortune = fortuneCookies[Math.floor(Math.random() * fortuneCookies.length)]
    setFortuneCookie(randomFortune)
    setShowFortune(true)
  }

  const triggerPanicMode = () => {
    updateInteraction()
    setPotatoMood(0)
    setIsPanicMode(true)
    setTimeout(() => {
      setIsPanicMode(false)
      setPotatoMood(30)
    }, 5000)
  }

  // Chase game logic (keeping existing functionality)
  useEffect(() => {
    if (isChaseActive && !hasWon && !potatoCaught) {
      const timer = setInterval(() => {
        setChaseTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            setHasWon(true)
            setIsChaseActive(false)
            setPotatoMood(Math.min(100, potatoMood + 20))
            return 0
          }
          return prev - 1
        })
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [isChaseActive, hasWon, potatoCaught, potatoMood])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isChaseActive && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect()
        setMousePosition({
          x: ((e.clientX - rect.left) / rect.width) * 100,
          y: ((e.clientY - rect.top) / rect.height) * 100,
        })
      }
    }
    document.addEventListener("mousemove", handleMouseMove)
    return () => document.removeEventListener("mousemove", handleMouseMove)
  }, [isChaseActive])

  useEffect(() => {
    if (isChaseActive && !hasWon && !potatoCaught) {
      const distance = Math.sqrt(
        Math.pow(mousePosition.x - potatoPosition.x, 2) + Math.pow(mousePosition.y - potatoPosition.y, 2),
      )
      if (distance < 5) {
        setPotatoCaught(true)
        setIsChaseActive(false)
        setPotatoMood(Math.max(0, potatoMood - 30))
        return
      }
      if (distance < 25) {
        const angle = Math.atan2(potatoPosition.y - mousePosition.y, potatoPosition.x - mousePosition.x)
        let newX = potatoPosition.x + Math.cos(angle) * 10
        let newY = potatoPosition.y + Math.sin(angle) * 10
        newX = Math.max(5, Math.min(95, newX))
        newY = Math.max(5, Math.min(95, newY))
        setPotatoPosition({ x: newX, y: newY })
      }
    }
  }, [mousePosition, potatoPosition, isChaseActive, hasWon, potatoCaught, potatoMood])

  const startChase = () => {
    updateInteraction()
    setActiveSection("chase")
    setIsChaseActive(true)
    setHasWon(false)
    setPotatoCaught(false)
    setChaseTimer(30)
    setPotatoPosition({ x: 50, y: 50 })
  }

  const getRoast = () => {
    const roasts = [
      "At least you're not a boiled potato in a buffet.",
      "Remember that time you said 'you too' to the waiter? Oh wait...",
      "At least you're not the person who invented pineapple on pizza.",
      "Could be worse - you could be a potato that peaked in high school.",
      "At least you're not still using Internet Explorer.",
      "Remember when you pushed a door that said 'pull'? Classic you.",
      "Could be worse - you could be a potato that peaked in high school.",
      "At least you're not still using Internet Explorer.",
      "Remember when you pushed a door that said 'pull'? Classic you.",
      "Could be worse - you could be a potato that peaked in high school.",
    ]
    return roasts[Math.floor(Math.random() * roasts.length)]
  }

  const startRoast = () => {
    updateInteraction()
    setPotatoMood(Math.max(0, potatoMood - 5))
    setCurrentRoast(getRoast())
    setShowRoast(true)
  }

  const resetToMain = () => {
    setActiveSection("main")
    setQuestion("")
    setIsThinking(false)
    setThoughtIndex(0)
    setShowResult(false)
    setIsChaseActive(false)
    setHasWon(false)
    setPotatoCaught(false)
    setChaseTimer(30)
    setShowRoast(false)
    setCurrentRoast("")
    setShowFortune(false)
    setIsPanicMode(false)
    updateInteraction()
  }

  const getMoodColor = () => {
    if (potatoMood > 70) return "bg-green-400"
    if (potatoMood > 40) return "bg-yellow-400"
    if (potatoMood > 20) return "bg-orange-400"
    return "bg-red-400"
  }

  const getMoodEmoji = () => {
    if (isPanicMode) return "😱"
    if (potatoMood > 80) return "😊"
    if (potatoMood > 60) return "🙂"
    if (potatoMood > 40) return "😐"
    if (potatoMood > 20) return "😕"
    return "😭"
  }

  const Potato = ({
    size = "large",
    isChase = false,
    onClick,
  }: { size?: "small" | "medium" | "large"; isChase?: boolean; onClick?: () => void }) => {
    const sizes = { small: "w-12 h-12 text-xl", medium: "w-20 h-20 text-3xl", large: "w-28 h-28 text-5xl" }

    return (
      <div
        className={`${sizes[size]} ${currentMood.color} rounded-full flex items-center justify-center shadow-lg transition-all duration-200 hover:scale-105 ${isChase ? "absolute cursor-pointer" : ""} ${isPanicMode ? "animate-bounce" : ""}`}
        style={
          isChase
            ? {
                left: `${potatoPosition.x}%`,
                top: `${potatoPosition.y}%`,
                transform: "translate(-50%, -50%)",
              }
            : {}
        }
        onClick={onClick}
      >
        {isPanicMode ? "😱" : potatoCaught ? "🥔😭" : getMoodEmoji()}
      </div>
    )
  }

  const SpeechBubble = ({
    message,
    children,
    className = "",
  }: { message?: string; children?: React.ReactNode; className?: string }) => (
    <div className={`relative bg-white rounded-2xl p-4 shadow-lg border border-gray-100 max-w-xs mx-auto ${className}`}>
      <div className="text-gray-700 text-sm text-center font-medium">{message || children}</div>
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full">
        <div className="w-0 h-0 border-l-4 border-r-4 border-t-8 border-l-transparent border-r-transparent border-t-white"></div>
      </div>
    </div>
  )

  const currentThemeData = themes[currentTheme]

  return (
    <div
      className={`min-h-screen bg-gradient-to-br ${currentThemeData.bg} flex flex-col items-center justify-center p-6 transition-all duration-500`}
    >
      {/* Mood Bar */}
      <div className="fixed top-4 left-4 right-4 z-50">
        <div className="bg-white/20 rounded-full p-2 backdrop-blur-sm">
          <div className="flex items-center gap-2 text-white text-sm">
            <span>Mood:</span>
            <div className="flex-1 bg-white/30 rounded-full h-2">
              <div
                className={`h-full rounded-full transition-all duration-300 ${getMoodColor()}`}
                style={{ width: `${potatoMood}%` }}
              />
            </div>
            <span>{getMoodEmoji()}</span>
          </div>
        </div>
      </div>

      {/* Theme Selector */}
      <div className="fixed top-4 right-4 z-50">
        <select
          value={currentTheme}
          onChange={(e) => setCurrentTheme(e.target.value)}
          className="bg-white/20 text-white rounded-lg p-2 backdrop-blur-sm border border-white/30"
        >
          {Object.entries(themes).map(([key, theme]) => (
            <option key={key} value={key} className="text-black">
              {theme.name}
            </option>
          ))}
        </select>
      </div>

      {/* Header */}
      <div className="text-center mb-8">
        <h1 className={`text-5xl font-bold text-${currentThemeData.text} drop-shadow-lg mb-2`}>Moody Potato</h1>
        <p className={`text-${currentThemeData.text}/80 text-sm drop-shadow`}>
          {personas[currentPersona].name} • {currentMood.mood} mood • {currentTime.getHours()}:00
        </p>
      </div>

      {/* Panic Mode Overlay */}
      {isPanicMode && (
        <div className="fixed inset-0 bg-red-500/50 flex items-center justify-center z-40 animate-pulse">
          <div className="text-center text-white">
            <div className="text-6xl mb-4">🚨</div>
            <div className="text-2xl font-bold mb-2">WE'RE DOOMED!</div>
            <div className="text-lg">*spinning in corner*</div>
            <div className="text-sm mt-4 opacity-75">Okay, breathe. We're fine. Probably.</div>
          </div>
        </div>
      )}

      {/* Main Section */}
      {activeSection === "main" && (
        <div className="text-center space-y-8 max-w-md">
          {showIdleAnimation && (
            <div className="animate-bounce">
              <SpeechBubble message="Are you ignoring me? 🥺" />
            </div>
          )}

          {!showIdleAnimation && <SpeechBubble message={currentMood.message} />}

          <Potato size="large" />

          {/* Persona Selector */}
          <div className="flex gap-2 justify-center flex-wrap">
            {Object.entries(personas).map(([key, persona]) => (
              <button
                key={key}
                onClick={() => {
                  setCurrentPersona(key)
                  updateInteraction()
                }}
                className={`px-3 py-1 rounded-full text-sm transition-all ${
                  currentPersona === key
                    ? `bg-${currentThemeData.accent} text-white`
                    : `bg-white/20 text-${currentThemeData.text}`
                }`}
              >
                {persona.emoji} {persona.name}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setActiveSection("ask")}
              className={`bg-blue-500 hover:bg-blue-600 text-white font-medium py-3 px-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105`}
            >
              🤔 Ask Potato
            </button>
            <button
              onClick={startChase}
              className="bg-green-500 hover:bg-green-600 text-white font-medium py-3 px-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105"
            >
              🏃‍♂️ Catch Me!
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={crackFortuneCookie}
              className="bg-yellow-500 hover:bg-yellow-600 text-white font-medium py-3 px-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105"
            >
              🥠 Fortune Cookie
            </button>
            <button
              onClick={startRoast}
              className="bg-red-500 hover:bg-red-600 text-white font-medium py-3 px-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105"
            >
              😤 Roast Me
            </button>
          </div>

          <button
            onClick={triggerPanicMode}
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105 border-2 border-red-400"
          >
            🚨 DON'T CLICK (Panic Button)
          </button>

          {showFortune && (
            <div className="mt-6 space-y-4">
              <div className="text-4xl">🥠💥</div>
              <SpeechBubble message={fortuneCookie} />
              <button
                onClick={() => setShowFortune(false)}
                className={`bg-${currentThemeData.accent} hover:opacity-80 text-white px-4 py-2 rounded-lg`}
              >
                Thanks, I guess
              </button>
            </div>
          )}

          {showRoast && (
            <div className="mt-6 space-y-4">
              <SpeechBubble message={currentRoast} />
              <div className="text-center">
                <p className={`text-${currentThemeData.text}/80 text-sm mb-2 drop-shadow`}>Rate the roast:</p>
                <div className="flex justify-center gap-2">
                  {["🌶️", "🌶️🌶️", "🔥", "🔥🔥", "🔥🔥🔥"].map((level, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        setShowRoast(false)
                        setPotatoMood(Math.min(100, potatoMood + 5))
                      }}
                      className="bg-white/20 hover:bg-white/30 rounded-lg px-3 py-2 text-lg transition-all duration-200 hover:scale-110"
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Ask Section */}
      {activeSection === "ask" && (
        <div className="text-center space-y-6 max-w-md">
          <SpeechBubble message="Ask me anything! I'll overthink it for you." />
          <Potato size="medium" />
          <div className="space-y-4">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Should I eat pizza for breakfast?"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:outline-none text-center shadow-lg"
            />
            <div className="flex gap-3">
              <button
                onClick={startOverthinking}
                disabled={!question.trim()}
                className="flex-1 bg-purple-500 hover:bg-purple-600 disabled:bg-gray-300 text-white font-medium py-3 px-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Think Hard!
              </button>
              <button
                onClick={resetToMain}
                className="bg-gray-500 hover:bg-gray-600 text-white font-medium py-3 px-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Thinking Section */}
      {activeSection === "thinking" && (
        <div
          className={`min-h-screen bg-gradient-to-br ${personaAtmospheres[currentPersona].thinkingBg} flex flex-col items-center justify-center p-6 transition-all duration-1000 fixed inset-0 z-30`}
        >
          <div className="text-center space-y-6 max-w-md">
            {isThinking && (
              <>
                {/* Persona-specific thinking atmosphere */}
                {currentPersona === "therapist" && (
                  <div className="absolute inset-0 opacity-20">
                    <div className="text-6xl animate-pulse">🧠</div>
                    <div className="text-4xl animate-bounce delay-100">📋</div>
                    <div className="text-5xl animate-pulse delay-200">💭</div>
                  </div>
                )}

                {currentPersona === "gossip" && (
                  <div className="absolute inset-0 opacity-30">
                    {[...Array(10)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute text-2xl animate-bounce"
                        style={{
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                          animationDelay: `${Math.random() * 2}s`,
                        }}
                      >
                        ☕
                      </div>
                    ))}
                  </div>
                )}

                {currentPersona === "shy" && (
                  <div className="absolute inset-0 opacity-20">
                    <div className="text-8xl animate-pulse text-center">🙈</div>
                    <div className="text-sm text-center mt-4 opacity-50">*whispers*</div>
                  </div>
                )}

                {currentPersona === "passive" && (
                  <div className="absolute inset-0 opacity-30">
                    <div className="text-6xl text-center animate-pulse">😒</div>
                    <div className="text-xs text-center mt-4 opacity-70">*sighs heavily*</div>
                  </div>
                )}

                <SpeechBubble className={personaAtmospheres[currentPersona].bubbleStyle}>
                  <div className="text-xs font-medium">
                    {(overthinkingThoughts[currentPersona] || overthinkingThoughts.default)[thoughtIndex]}
                  </div>
                </SpeechBubble>

                <div className={personaAtmospheres[currentPersona].spinSpeed}>
                  <Potato size="medium" />
                </div>

                <div className={`${personaAtmospheres[currentPersona].textColor} text-sm drop-shadow`}>
                  {currentPersona === "therapist" && "Analyzing..."}
                  {currentPersona === "gossip" && "Spilling tea..."}
                  {currentPersona === "shy" && "Sorry for thinking..."}
                  {currentPersona === "passive" && "Whatever..."}
                  {currentPersona === "default" &&
                    `Thought ${thoughtIndex + 1} of ${overthinkingThoughts[currentPersona].length}...`}
                </div>

                {/* Persona-specific progress indicators */}
                {currentPersona === "therapist" && (
                  <div className="text-blue-200 text-xs">
                    Session progress: {Math.round((thoughtIndex / overthinkingThoughts[currentPersona].length) * 100)}%
                  </div>
                )}

                {currentPersona === "gossip" && (
                  <div className="text-pink-200 text-xs animate-pulse">
                    ☕ Tea temperature: {thoughtIndex < 5 ? "Lukewarm" : thoughtIndex < 10 ? "Hot" : "SCALDING"} ☕
                  </div>
                )}

                {currentPersona === "shy" && (
                  <div className="text-gray-300 text-xs">
                    Anxiety level:{" "}
                    {thoughtIndex < 5 ? "Mild concern" : thoughtIndex < 10 ? "Moderate worry" : "Full spiral"}
                  </div>
                )}

                {currentPersona === "passive" && (
                  <div className="text-gray-300 text-xs">
                    Caring level: {Math.max(0, 100 - thoughtIndex * 7)}% (decreasing...)
                  </div>
                )}
              </>
            )}

            {showResult && (
              <>
                <SpeechBubble message={getPersonaAnswer()} />
                <Potato size="medium" />
                <button
                  onClick={resetToMain}
                  className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-3 px-6 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  {currentPersona === "therapist"
                    ? "End Session"
                    : currentPersona === "gossip"
                      ? "Spill More Tea"
                      : currentPersona === "shy"
                        ? "Sorry for asking..."
                        : currentPersona === "passive"
                          ? "Whatever, ask again"
                          : "Ask Another Question"}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Chase Section */}
      {activeSection === "chase" && (
        <div
          ref={containerRef}
          className="relative w-full h-96 max-w-2xl bg-gradient-to-br from-yellow-300 via-green-400 to-cyan-400 rounded-2xl overflow-hidden shadow-2xl border-4 border-white"
        >
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 text-center z-10">
            <h3 className="text-2xl font-bold text-purple-800 drop-shadow-lg mb-2">Catch the Potato!</h3>
            {isChaseActive && (
              <div className="text-purple-700 font-medium drop-shadow">
                Time left: {chaseTimer}s • Move your mouse to chase!
              </div>
            )}
            {hasWon && (
              <div className="text-green-800 font-bold animate-bounce drop-shadow-lg">{"Time's up! You win! 🎉"}</div>
            )}
            {potatoCaught && (
              <div className="text-red-800 font-bold animate-bounce drop-shadow-lg">You caught me! 😭</div>
            )}
            {!isChaseActive && !hasWon && !potatoCaught && (
              <div className="text-purple-700 drop-shadow">Click the potato to start chasing!</div>
            )}
          </div>

          {isChaseActive && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-0">
              <SpeechBubble message="You'll never catch me! 🏃‍♂️" className="animate-pulse" />
            </div>
          )}

          <Potato
            size="medium"
            isChase={true}
            onClick={() => {
              if (!isChaseActive && !hasWon && !potatoCaught) {
                setIsChaseActive(true)
              }
            }}
          />

          {(hasWon || potatoCaught) && (
            <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 z-10">
              <SpeechBubble
                message={hasWon ? "Okay, you outlasted me! Good job! 🏆" : "Ow! You actually caught me! 😭"}
              />
            </div>
          )}

          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 z-10">
            <button
              onClick={resetToMain}
              className="bg-purple-500 hover:bg-purple-600 text-white font-medium py-2 px-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Back Home
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default MoodyPotatoApp
